
-- views.sql
-- Business views for stock speed, days of cover, and sales

DROP VIEW IF EXISTS vw_stock_speed CASCADE;

-- Stock speed & Days of Cover over the last 90 days of sales
CREATE VIEW vw_stock_speed AS
WITH sales_90d AS (
    SELECT
        fs.warehouse_id,
        fs.product_id,
        MAX(fs.sale_date) AS last_sale_date,
        SUM(fs.quantity) FILTER (
            WHERE fs.sale_date >= CURRENT_DATE - INTERVAL '90 days'
        ) AS sales_qty_90d
    FROM fact_sales fs
    GROUP BY fs.warehouse_id, fs.product_id
),
combined AS (
    SELECT
        s.warehouse_id,
        w.branch,
        s.product_id,
        p.product_name,
        p.brand,
        c.cat_name,
        c.sub_cat_name,
        s.quantity AS on_hand_qty,
        COALESCE(sales_90d.sales_qty_90d, 0) AS sales_qty_90d,
        sales_90d.last_sale_date,
        CASE 
            WHEN COALESCE(sales_90d.sales_qty_90d, 0) = 0 THEN NULL
            ELSE ROUND((COALESCE(s.quantity,0) / (sales_90d.sales_qty_90d / 90.0))::numeric, 1)
        END AS days_of_cover
    FROM stocks s
    JOIN dim_warehouses w ON s.warehouse_id = w.warehouse_id
    JOIN dim_products p ON s.product_id = p.product_id
    LEFT JOIN categories c ON p.category_id = c.category_id
    LEFT JOIN sales_90d ON s.warehouse_id = sales_90d.warehouse_id
                        AND s.product_id   = sales_90d.product_id
)
SELECT
    warehouse_id,
    branch,
    product_id,
    product_name,
    brand,
    cat_name,
    sub_cat_name,
    on_hand_qty,
    sales_qty_90d,
    days_of_cover,
    last_sale_date,
    CASE
        WHEN sales_qty_90d = 0 THEN 'NO_SALES'
        WHEN days_of_cover IS NULL THEN 'NO_SALES'
        WHEN days_of_cover > 120 THEN 'OVER_STOCK'
        WHEN days_of_cover BETWEEN 31 AND 120 THEN 'SLOW'
        WHEN days_of_cover BETWEEN 8 AND 30 THEN 'MEDIUM'
        ELSE 'FAST'
    END AS stock_speed
FROM combined;
