
# Retail Stock & Sales Data Warehouse (PostgreSQL Demo)

This repository contains a **PostgreSQL-based demo data warehouse** designed for
**retail stock & sales analytics**. It is the same style of model used in my BI portfolio
(Stock Dashboard, Days of Cover, Stock Speed).

You can use it as:
- A learning environment for SQL & data modeling
- A backend for Power BI dashboards
- A demo project to showcase BI/Data Analytics skills

---

## 📂 Files

- `tables.sql`  
  Create all core tables:
  - `dim_products`, `dim_customers`, `dim_warehouses`
  - `categories`, `districts`
  - `stocks`, `fact_sales`

- `sample_data.sql`  
  Minimal sample data for:
  - Categories, products, customers, warehouses, stocks
  - Sales over the last 90–120 days

- `views.sql`  
  Business logic in SQL:
  - `vw_stock_speed` view with:
    - On-hand quantity
    - 90-day sales quantity
    - Days of Cover
    - Stock speed classification (`NO_SALES`, `SLOW`, `MEDIUM`, `FAST`, `OVER_STOCK`)

---

## 🚀 How to Use

1. Create a new PostgreSQL database, e.g.

   ```sql
   CREATE DATABASE retail_dw;
   ```

2. Run `tables.sql`:

   ```bash
   psql -d retail_dw -f tables.sql
   ```

3. Load sample data:

   ```bash
   psql -d retail_dw -f sample_data.sql
   ```

4. Create business views:

   ```bash
   psql -d retail_dw -f views.sql
   ```

5. Connect **Power BI / DBeaver / n8n** to this database and start building:
   - Stock dashboards
   - Branch performance
   - Category & product drilldowns
   - Red zone / risk SKU analytics

---

## 🧠 Metrics Included

- **On Hand Qty** per warehouse & product  
- **Sales Qty 90 days**  
- **Days of Cover** (DOC)  
- **Stock Speed** classification  
- **Last Sale Date**

These are the same concepts used in my BI portfolio for:
- Stock dashboard
- Red zone / war room view
- Branch/category drilldown

---

## 🔧 Tools

- PostgreSQL
- DBeaver / pgAdmin
- Power BI
- n8n (optional for automation/AI agent)

---

## 👤 Author

Created by **Thana Pattanaverakit**  
Data Analytics / Business Intelligence / AI Automation
