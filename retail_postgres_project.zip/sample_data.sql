
-- sample_data.sql
-- Minimal demo data for the Retail Data Warehouse

TRUNCATE fact_sales RESTART IDENTITY CASCADE;
TRUNCATE stocks RESTART IDENTITY CASCADE;
TRUNCATE dim_products RESTART IDENTITY CASCADE;
TRUNCATE dim_customers RESTART IDENTITY CASCADE;
TRUNCATE dim_warehouses RESTART IDENTITY CASCADE;
TRUNCATE categories RESTART IDENTITY CASCADE;
TRUNCATE districts RESTART IDENTITY CASCADE;

INSERT INTO categories (cat_name, sub_cat_name) VALUES
('Beverage', 'Soft Drink'),
('Beverage', 'Energy Drink'),
('Snack', 'Chip'),
('Snack', 'Biscuit');

INSERT INTO districts (province, district_name, district_en) VALUES
('Bangkok', 'Huai Khwang', 'Huai Khwang'),
('Bangkok', 'Chatuchak', 'Chatuchak');

INSERT INTO dim_customers (full_name, gender, age, address, city, district_id) VALUES
('Somchai Prasert', 'M', 35, 'Ratchada Rd.', 'Bangkok', 1),
('Suda Intanon', 'F', 29, 'Lat Phrao Rd.', 'Bangkok', 2);

INSERT INTO dim_warehouses (warehouse_name, address, city, branch) VALUES
('Central DC', 'Rama 9', 'Bangkok', 'BKK-DC'),
('Branch 101', 'Huai Khwang', 'Bangkok', 'BKK-01');

INSERT INTO dim_products (product_name, brand, sku_id, category_id, unit_cost, unit_price) VALUES
('Cola 330ml', 'ColaX', 'SKU-001', 1, 8.00, 12.00),
('Energy Drink 250ml', 'BoostUp', 'SKU-002', 2, 10.00, 15.00),
('Potato Chips 50g', 'Crispy', 'SKU-003', 3, 12.00, 20.00),
('Butter Biscuit 100g', 'GoldenBite', 'SKU-004', 4, 14.00, 22.00);

-- Initial stock in each warehouse
INSERT INTO stocks (warehouse_id, product_id, quantity, total_cost) VALUES
(1, 1, 500, 500 * 8.00),
(1, 2, 400, 400 * 10.00),
(1, 3, 300, 300 * 12.00),
(2, 1, 120, 120 * 8.00),
(2, 2, 80,  80  * 10.00),
(2, 4, 150, 150 * 14.00);

-- Sample sales over last 120 days
INSERT INTO fact_sales (sale_date, warehouse_id, customer_id, product_id, quantity, unit_price, line_revenue, line_cost, line_profit) VALUES
(current_date - INTERVAL '5 days',  2, 1, 1, 24, 12.00, 24*12.00, 24*8.00,  24*(12-8)),
(current_date - INTERVAL '20 days', 2, 2, 1, 18, 12.00, 18*12.00, 18*8.00,  18*(12-8)),
(current_date - INTERVAL '35 days', 2, 1, 1, 30, 12.00, 30*12.00, 30*8.00,  30*(12-8)),
(current_date - INTERVAL '10 days', 1, 1, 2, 40, 15.00, 40*15.00, 40*10.00, 40*(15-10)),
(current_date - INTERVAL '50 days', 1, 2, 2, 25, 15.00, 25*15.00, 25*10.00, 25*(15-10)),
(current_date - INTERVAL '15 days', 1, 2, 3, 35, 20.00, 35*20.00, 35*12.00, 35*(20-12)),
(current_date - INTERVAL '90 days', 1, 1, 3, 10, 20.00, 10*20.00, 10*12.00, 10*(20-12));
