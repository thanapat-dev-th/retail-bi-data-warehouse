
-- tables.sql
-- PostgreSQL DDL for Retail Stock & Sales Data Warehouse Demo

DROP TABLE IF EXISTS fact_sales CASCADE;
DROP TABLE IF EXISTS stocks CASCADE;
DROP TABLE IF EXISTS dim_products CASCADE;
DROP TABLE IF EXISTS dim_customers CASCADE;
DROP TABLE IF EXISTS dim_warehouses CASCADE;
DROP TABLE IF EXISTS categories CASCADE;
DROP TABLE IF EXISTS districts CASCADE;

CREATE TABLE categories (
    category_id     SERIAL PRIMARY KEY,
    cat_name        TEXT NOT NULL,
    sub_cat_name    TEXT
);

CREATE TABLE districts (
    district_id     SERIAL PRIMARY KEY,
    province        TEXT NOT NULL,
    district_name   TEXT NOT NULL,
    district_en     TEXT
);

CREATE TABLE dim_customers (
    customer_id     SERIAL PRIMARY KEY,
    full_name       TEXT NOT NULL,
    gender          TEXT,
    age             INT,
    address         TEXT,
    city            TEXT,
    district_id     INT REFERENCES districts(district_id)
);

CREATE TABLE dim_warehouses (
    warehouse_id    SERIAL PRIMARY KEY,
    warehouse_name  TEXT NOT NULL,
    address         TEXT,
    city            TEXT,
    branch          TEXT NOT NULL
);

CREATE TABLE dim_products (
    product_id      SERIAL PRIMARY KEY,
    product_name    TEXT NOT NULL,
    brand           TEXT,
    sku_id          TEXT UNIQUE,
    category_id     INT REFERENCES categories(category_id),
    unit_cost       NUMERIC(12,2),
    unit_price      NUMERIC(12,2)
);

CREATE TABLE fact_sales (
    sale_id         SERIAL PRIMARY KEY,
    sale_date       DATE NOT NULL,
    warehouse_id    INT NOT NULL REFERENCES dim_warehouses(warehouse_id),
    customer_id     INT NOT NULL REFERENCES dim_customers(customer_id),
    product_id      INT NOT NULL REFERENCES dim_products(product_id),
    quantity        NUMERIC(12,2) NOT NULL,
    unit_price      NUMERIC(12,2) NOT NULL,
    line_revenue    NUMERIC(14,2),
    line_cost       NUMERIC(14,2),
    line_profit     NUMERIC(14,2)
);

CREATE TABLE stocks (
    warehouse_id    INT NOT NULL REFERENCES dim_warehouses(warehouse_id),
    product_id      INT NOT NULL REFERENCES dim_products(product_id),
    quantity        NUMERIC(12,2) NOT NULL,
    total_cost      NUMERIC(14,2),
    PRIMARY KEY (warehouse_id, product_id)
);
